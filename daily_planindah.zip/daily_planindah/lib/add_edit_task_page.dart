import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'schedule_provider.dart';
import 'schedule.dart';

class AddEditTaskPage extends StatefulWidget {
  final Schedule? schedule;
  const AddEditTaskPage({Key? key, this.schedule}) : super(key: key);

  @override
  State<AddEditTaskPage> createState() => _AddEditTaskPageState();
}

class _AddEditTaskPageState extends State<AddEditTaskPage> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController _titleController;
  late TextEditingController _dateController;
  late TextEditingController _startTimeController;
  late TextEditingController _endTimeController;

  @override
  void initState() {
    super.initState();
    _titleController = TextEditingController(text: widget.schedule?.title ?? '');
    _dateController = TextEditingController(text: widget.schedule?.date ?? '');
    _startTimeController = TextEditingController(text: widget.schedule?.startTime ?? '');
    _endTimeController = TextEditingController(text: widget.schedule?.endTime ?? '');
  }

  @override
  void dispose() {
    _titleController.dispose();
    _dateController.dispose();
    _startTimeController.dispose();
    _endTimeController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<ScheduleProvider>(context, listen: false);

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.schedule == null ? 'Tambah Jadwal' : 'Edit Jadwal'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              TextFormField(
                controller: _titleController,
                decoration: const InputDecoration(labelText: 'Judul Kegiatan'),
                validator: (value) => value == null || value.isEmpty ? 'Judul wajib diisi' : null,
              ),
              const SizedBox(height: 10),
              TextFormField(
                controller: _dateController,
                decoration: const InputDecoration(labelText: 'Tanggal (YYYY-MM-DD)'),
                validator: (value) => value == null || value.isEmpty ? 'Tanggal wajib diisi' : null,
              ),
              const SizedBox(height: 10),
              TextFormField(
                controller: _startTimeController,
                decoration: const InputDecoration(labelText: 'Waktu Mulai (HH:MM)'),
                validator: (value) => value == null || value.isEmpty ? 'Waktu mulai wajib diisi' : null,
              ),
              const SizedBox(height: 10),
              TextFormField(
                controller: _endTimeController,
                decoration: const InputDecoration(labelText: 'Waktu Selesai (HH:MM)'),
                validator: (value) => value == null || value.isEmpty ? 'Waktu selesai wajib diisi' : null,
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: () async {
                  if (_formKey.currentState!.validate()) {
                    final newSchedule = Schedule(
                      id: widget.schedule?.id,
                      title: _titleController.text,
                      date: _dateController.text,
                      startTime: _startTimeController.text,
                      endTime: _endTimeController.text,
                    );
                    if (widget.schedule == null) {
                      await provider.addSchedule(newSchedule);
                    } else {
                      await provider.updateSchedule(newSchedule);
                    }
                    if (mounted) Navigator.pop(context);
                  }
                },
                child: const Text('Simpan'),
              )
            ],
          ),
        ),
      ),
    );
  }
}
