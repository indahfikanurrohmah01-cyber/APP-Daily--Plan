import 'package:flutter/material.dart';
import 'database_helper.dart';
import 'schedule.dart';

class ScheduleProvider with ChangeNotifier {
  List<Schedule> _schedules = [];

  List<Schedule> get schedules => _schedules;

  Future<void> fetchSchedules() async {
    final dataList = await DatabaseHelper().getAllSchedules();
    _schedules = dataList.map((item) => Schedule.fromMap(item)).toList();
    notifyListeners();
  }

  Future<void> addSchedule(Schedule schedule) async {
    await DatabaseHelper().insertSchedule(schedule.toMap());
    await fetchSchedules();
  }

  Future<void> updateSchedule(Schedule schedule) async {
    if (schedule.id != null) {
      await DatabaseHelper().updateSchedule(schedule.id!, schedule.toMap());
      await fetchSchedules();
    }
  }

  Future<void> deleteSchedule(int id) async {
    await DatabaseHelper().deleteSchedule(id);
    await fetchSchedules();
  }
}
