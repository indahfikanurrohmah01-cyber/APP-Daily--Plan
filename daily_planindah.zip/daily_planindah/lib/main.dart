import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'schedule_provider.dart';
import 'home_page.dart';

void main() {
  runApp(const DailyPlanApp());
}

class DailyPlanApp extends StatelessWidget {
  const DailyPlanApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => ScheduleProvider()..fetchSchedules(),
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'DailyPlan',
        theme: ThemeData(primarySwatch: Colors.blue),
        home: const HomePage(),
      ),
    );
  }
}
