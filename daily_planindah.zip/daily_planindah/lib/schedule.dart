class Schedule {
  int? id;
  String title;
  String date;
  String startTime;
  String endTime;

  Schedule({
    this.id,
    required this.title,
    required this.date,
    required this.startTime,
    required this.endTime,
  });

  Map<String, dynamic> toMap() {
    final map = <String, dynamic>{
      'title': title,
      'date': date,
      'startTime': startTime,
      'endTime': endTime,
    };
    if (id != null) {
      map['id'] = id;
    }
    return map;
  }

  factory Schedule.fromMap(Map<String, dynamic> map) {
    return Schedule(
      id: map['id'],
      title: map['title'],
      date: map['date'],
      startTime: map['startTime'],
      endTime: map['endTime'],
    );
  }
}
