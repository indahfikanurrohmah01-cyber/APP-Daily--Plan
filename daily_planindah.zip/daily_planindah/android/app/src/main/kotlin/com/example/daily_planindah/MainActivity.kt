package com.example.daily_planindah

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
